// ===== Hati yang melayang di latar =====
const canvas = document.getElementById('hearts');
const ctx = canvas.getContext('2d');
let W, H, hearts = [];

function resize(){ W = canvas.width = innerWidth; H = canvas.height = innerHeight; }
addEventListener('resize', resize); resize();

function makeHeart(x, y, burst){
  return {
    x: x ?? Math.random() * W,
    y: y ?? H + 20,
    s: 10 + Math.random() * 22,
    vy: burst ? -(2 + Math.random() * 4) : -(0.4 + Math.random() * 1.1),
    vx: burst ? (Math.random() - 0.5) * 6 : (Math.random() - 0.5) * 0.6,
    a: burst ? 1 : 0.2 + Math.random() * 0.5,
    c: ['#ff7aa8', '#ffd6e3', '#ff4d88', '#f4c27a'][Math.floor(Math.random() * 4)],
    burst
  };
}

function drawHeart(h){
  ctx.save();
  ctx.globalAlpha = h.a;
  ctx.fillStyle = h.c;
  ctx.translate(h.x, h.y);
  const s = h.s / 2;
  ctx.beginPath();
  ctx.moveTo(0, s * .4);
  ctx.bezierCurveTo(-s * 1.4, -s * .6, -s * .5, -s * 1.5, 0, -s * .6);
  ctx.bezierCurveTo(s * .5, -s * 1.5, s * 1.4, -s * .6, 0, s * .4);
  ctx.fill();
  ctx.restore();
}

function loop(){
  ctx.clearRect(0, 0, W, H);
  if (Math.random() < 0.08) hearts.push(makeHeart());
  hearts.forEach(h => {
    h.x += h.vx; h.y += h.vy;
    if (h.burst){ h.vy += 0.05; h.a -= 0.008; }
    drawHeart(h);
  });
  hearts = hearts.filter(h => h.y > -40 && h.a > 0);
  requestAnimationFrame(loop);
}
loop();

function burst(n = 60, x = W / 2, y = H / 2){
  for (let i = 0; i < n; i++) hearts.push(makeHeart(x, y, true));
}

// ===== Buka hadiah =====
document.getElementById('openBtn').addEventListener('click', () => {
  document.getElementById('intro').classList.add('gone');
  document.getElementById('content').classList.remove('hidden');
  burst(120);
  observeReveal();
});

// ===== Muncul pelan saat digulir =====
function observeReveal(){
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting){ e.target.classList.add('show'); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
}

// ===== Tombol cinta =====
document.getElementById('loveBtn').addEventListener('click', e => {
  const r = e.target.getBoundingClientRect();
  burst(90, r.left + r.width / 2, r.top + r.height / 2);
});

// ===== Lightbox foto =====
const lb = document.getElementById('lightbox');
document.querySelectorAll('.grid img').forEach(img => {
  img.addEventListener('click', () => { lb.querySelector('img').src = img.src; lb.classList.add('on'); });
});
lb.addEventListener('click', () => lb.classList.remove('on'));
