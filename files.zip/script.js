// ===== Hati melayang di latar belakang =====
const canvas = document.getElementById('hearts');
const ctx = canvas.getContext('2d');
let W, H, hearts = [], bursts = [];

function resize() { W = canvas.width = innerWidth; H = canvas.height = innerHeight; }
addEventListener('resize', resize); resize();

function makeHeart(x, y, burst) {
  return {
    x: x ?? Math.random() * W,
    y: y ?? H + 20,
    s: burst ? 10 + Math.random() * 16 : 8 + Math.random() * 14,
    vx: burst ? (Math.random() - .5) * 8 : (Math.random() - .5) * .6,
    vy: burst ? -(2 + Math.random() * 7) : -(.4 + Math.random() * .9),
    a: burst ? 1 : .15 + Math.random() * .35,
    c: ['#e9a3b8', '#d6456b', '#ffd9e0', '#e0bb8a'][Math.floor(Math.random() * 4)],
    burst
  };
}

function drawHeart(h) {
  ctx.save();
  ctx.globalAlpha = h.a;
  ctx.fillStyle = h.c;
  ctx.translate(h.x, h.y);
  ctx.scale(h.s / 16, h.s / 16);
  ctx.beginPath();
  ctx.moveTo(0, 6);
  ctx.bezierCurveTo(-16, -6, -8, -18, 0, -8);
  ctx.bezierCurveTo(8, -18, 16, -6, 0, 6);
  ctx.fill();
  ctx.restore();
}

function loop() {
  ctx.clearRect(0, 0, W, H);
  if (hearts.length < 28 && Math.random() < .06) hearts.push(makeHeart());
  hearts = hearts.filter(h => h.y > -30);
  hearts.forEach(h => { h.x += h.vx + Math.sin(h.y / 40) * .3; h.y += h.vy; drawHeart(h); });

  bursts = bursts.filter(h => h.a > .02);
  bursts.forEach(h => { h.x += h.vx; h.y += h.vy; h.vy += .12; h.vx *= .99; h.a -= .008; drawHeart(h); });
  requestAnimationFrame(loop);
}
loop();

function burstHearts(x, y, n = 40) {
  for (let i = 0; i < n; i++) bursts.push(makeHeart(x, y, true));
}

// ===== Buka amplop =====
const cover = document.getElementById('cover');
const main = document.getElementById('main');
document.getElementById('envelope').addEventListener('click', e => {
  const r = e.currentTarget.getBoundingClientRect();
  burstHearts(r.left + r.width / 2, r.top + r.height / 2, 60);
  cover.classList.add('gone');
  main.classList.remove('hidden');
  window.scrollTo(0, 0);
  setTimeout(() => { cover.style.display = 'none'; observeReveals(); }, 900);
});

// ===== Teks muncul saat di-scroll =====
function observeReveals() {
  const io = new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (en.isIntersecting) { en.target.classList.add('show'); io.unobserve(en.target); }
    });
  }, { threshold: .2 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
}

// ===== Tombol kirim cinta =====
document.getElementById('loveBtn').addEventListener('click', e => {
  const r = e.currentTarget.getBoundingClientRect();
  burstHearts(r.left + r.width / 2, r.top + r.height / 2, 80);
  e.currentTarget.textContent = 'I love you ❤️';
});

// ===== Lightbox foto =====
const lb = document.getElementById('lightbox');
const lbImg = lb.querySelector('img');
document.addEventListener('click', e => {
  const img = e.target.closest('img[data-zoom]');
  if (img) { lbImg.src = img.src; lbImg.alt = img.alt; lb.hidden = false; }
  else if (!lb.hidden) lb.hidden = true;
});
addEventListener('keydown', e => { if (e.key === 'Escape') lb.hidden = true; });
